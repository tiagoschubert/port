<?php include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?>

<div class="server_error">
    <h1>Server error!</h1>
    <p>Sorry the server is experiencing some techincal difficulties. PLease check back later</p>

</div>


<?php include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?>