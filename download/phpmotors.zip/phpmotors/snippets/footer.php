</main>
<footer>
    <p>&copy; PHP Motors, All rights reseved.</p>
    <p>All images used are believed to be in "Fair Use". Please notify the author if any are not and they will be removed.</p>
    <div id="current_date">Last Updated 12/Jan/2021</div>

</footer>
</div>
<script src='../js/script.js'></script>
</body>

</html>